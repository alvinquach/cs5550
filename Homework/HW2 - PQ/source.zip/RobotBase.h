#pragma once
#include "RobotPart.h"

class RobotBase : public RobotPart {
public:
	RobotBase();
	~RobotBase();
	void draw();
};

