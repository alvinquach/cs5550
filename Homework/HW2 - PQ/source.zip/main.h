// Alvin Quach, 300793745
// CS5550 F17 - HW2 PQ

#pragma once
#include "Draw.h"
#include "Window.h"
#include "Input.h"
#include "Scene.h"
#include "Physics.h"
#include <vector>

void init(int argc, char** argv);
void display();
void timer(int value);
void callTimerFunc();
