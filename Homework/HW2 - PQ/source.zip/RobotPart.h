#pragma once
#include <gl/Gl.h>
#include "glut.h"
#include <windows.h>

class RobotPart {

public:
	virtual void draw();
};