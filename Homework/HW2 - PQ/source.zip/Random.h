// Alvin Quach, 300793745
// CS5550 F17 - HW2 PQ

#pragma once

class Random {
public:
	static int RandomInt(int max);
	static int RandomInt(int min, int max);
	static float RandomFloat(float max);
	static float RandomFloat(float min, float max);
};

