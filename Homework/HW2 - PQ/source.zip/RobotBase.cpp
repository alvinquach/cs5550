#include "RobotBase.h"
#include <gl/Gl.h>
#include "glut.h"
#include <windows.h>

RobotBase::RobotBase()
{
}


RobotBase::~RobotBase()
{
}

void RobotBase::draw() {

	glPushMatrix();

}
